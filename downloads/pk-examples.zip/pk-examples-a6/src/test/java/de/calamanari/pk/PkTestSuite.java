//@formatter:off
/*
 * PkTestSuite - Test suite for all pattern tests.
 * Code-Beispiel zum Buch Patterns Kompakt, Verlag Springer Vieweg
 * Copyright 2014 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"):
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
//@formatter:on
package de.calamanari.pk;

import org.junit.platform.suite.api.AfterSuite;
import org.junit.platform.suite.api.BeforeSuite;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.calamanari.pk.abstractfactory.AbstractFactoryTest;
import de.calamanari.pk.activeobject.ActiveObjectTest;
import de.calamanari.pk.adapter.AdapterTest;
import de.calamanari.pk.bridge.BridgeTest;
import de.calamanari.pk.builder.BuilderTest;
import de.calamanari.pk.coarsegrainedlock.CoarseGrainedLockTest;
import de.calamanari.pk.combinedmethod.CombinedMethodTest;
import de.calamanari.pk.command.CommandTest;
import de.calamanari.pk.commandprocessor.CommandProcessorTest;
import de.calamanari.pk.composite.CompositeTest;
import de.calamanari.pk.datatransferobject.DataTransferObjectTest;
import de.calamanari.pk.decorator.DecoratorTest;
import de.calamanari.pk.dependencyinjection.DependencyInjectionTest;
import de.calamanari.pk.facade.FacadeTest;
import de.calamanari.pk.factorymethod.FactoryMethodTest;
import de.calamanari.pk.flyweight.FlyweightTest;
import de.calamanari.pk.gateway.GatewayTest;
import de.calamanari.pk.identityfield.IdentityFieldTest;
import de.calamanari.pk.identitymap.IdentityMapTest;
import de.calamanari.pk.iterator.IteratorTest;
import de.calamanari.pk.lazyload.LazyLoadTest;
import de.calamanari.pk.leaderfollower.LeaderFollowerTest;
import de.calamanari.pk.mapper.MapperTest;
import de.calamanari.pk.modelviewcontroller.ModelViewControllerTest;
import de.calamanari.pk.money.MoneyTest;
import de.calamanari.pk.muhai.MuhaiTest;
import de.calamanari.pk.nullobject.NullObjectTest;
import de.calamanari.pk.objectpool.ObjectPoolTest;
import de.calamanari.pk.objectpool.SimpleThreadPoolTest;
import de.calamanari.pk.observer.ObserverTest;
import de.calamanari.pk.optimisticofflinelock.OptimisticOfflineLockTest;
import de.calamanari.pk.pessimisticofflinelock.PessimisticOfflineLockTest;
import de.calamanari.pk.plugin.PluginTest;
import de.calamanari.pk.proxy.ProxyTest;
import de.calamanari.pk.registry.RegistryTest;
import de.calamanari.pk.sequenceblock.SequenceBlockTest;
import de.calamanari.pk.servicestub.ServiceStubTest;
import de.calamanari.pk.singleton.SingletonTest;
import de.calamanari.pk.strategy.StrategyTest;
import de.calamanari.pk.templatemethod.TemplateMethodTest;
import de.calamanari.pk.transferobjectassembler.TransferObjectAssemblerTest;
import de.calamanari.pk.util.IndexedTextFileAccessorTest;
import de.calamanari.pk.util.ParallelFileInputStreamTest;
import de.calamanari.pk.util.TimeUtils;
import de.calamanari.pk.uuid.UUIDTest;
import de.calamanari.pk.valueobject.ValueObjectTest;
import de.calamanari.pk.visitor.VisitorTest;
import de.calamanari.pk.wrapper.WrapperTest;

/**
 * PkTestSuite - Test suite for all pattern tests.
 * <p>
 * This is a selection out of all available tests. <br>
 * To run also the others, first disable the suite using the Ignore annotation on this class. <br>
 * Then open the pom.xml and remove the sure-fire plugin configuration that limits the test execution to this suite.
 * <p>
 * Note: On the JUnit-testcases you will see a <code>&#64;SuppressedWarning("java:S5786")</code> annotation. The problem is that JUnit5 tests should be
 * package-protected rather than public. But this rule unfortunately makes it impossible to use the <code>&#64;SelectClasses</code> annotation below because the
 * tests come from various packages. Hence, the suite member classes are declared public.
 * 
 * @author <a href="mailto:Karl.Eilebrecht(a/t)calamanari.de">Karl Eilebrecht</a>
 */
@Suite
@SuiteDisplayName("Patterns Kompakt Test Suite")
@SelectClasses({
//@formatter:off
	AbstractFactoryTest.class,
	ActiveObjectTest.class,
	AdapterTest.class,
	BridgeTest.class,
	BuilderTest.class,
	CoarseGrainedLockTest.class,
	CombinedMethodTest.class,
	CommandProcessorTest.class,
	CommandTest.class,
	CompositeTest.class,
	DataTransferObjectTest.class,
	DecoratorTest.class,
	DependencyInjectionTest.class,
	FacadeTest.class,
	FactoryMethodTest.class,
	FlyweightTest.class,
	GatewayTest.class,
	IdentityFieldTest.class,
	IdentityMapTest.class,
	IndexedTextFileAccessorTest.class,
	IteratorTest.class,
	LazyLoadTest.class,
	MapperTest.class,
	LeaderFollowerTest.class,
	ModelViewControllerTest.class,
	MoneyTest.class,
	MuhaiTest.class,
	NullObjectTest.class,
	ObjectPoolTest.class,
	ObserverTest.class,
	OptimisticOfflineLockTest.class,
	ParallelFileInputStreamTest.class,
	PessimisticOfflineLockTest.class,
	PluginTest.class,
	ProxyTest.class,
	RegistryTest.class,
	SequenceBlockTest.class,
	ServiceStubTest.class,
	SimpleThreadPoolTest.class,
	SingletonTest.class,
	StrategyTest.class,
	TemplateMethodTest.class,
	TransferObjectAssemblerTest.class,
	UUIDTest.class,
	ValueObjectTest.class,
	VisitorTest.class,
	WrapperTest.class
	//@formatter:on
})
final class PkTestSuite {

    private static final Logger LOGGER = LoggerFactory.getLogger(PkTestSuite.class);

    /**
     * Time tests began
     */
    private static long startTimeNanos;

    /**
     * No instance required
     */
    private PkTestSuite() {
        // not required
    }

    /**
     * configure loggers before tests
     */
    @BeforeSuite
    static void beforeSuite() {
        startTimeNanos = System.nanoTime();
        LOGGER.info("Running Patterns Kompakt Test Suite ...");
    }

    /**
     * write finish message after tests
     */
    @AfterSuite
    static void afterSuite() {
        String elapsedTimeString = TimeUtils.formatNanosAsSeconds(System.nanoTime() - startTimeNanos);
        LOGGER.info("Patterns Kompakt Test Suite completed. Elapsed time: {} s", elapsedTimeString);
    }

}
